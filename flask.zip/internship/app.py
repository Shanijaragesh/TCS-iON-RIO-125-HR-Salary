import numpy as np
from flask import Flask, render_template, request
import pickle

# model loading
model = pickle.load(open('flask_gb_sm_model.pkl','rb'))
app = Flask(__name__)
@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    age = float(request.form['age'])
    workclass = float(request.form['workclass'])
    education = float(request.form['education'])
    marital_status = float(request.form['marital_status'])
    occupation = float(request.form['occupation'])
    relationship = float(request.form['relationship'])
    sex = float(request.form['sex'])
    race = float(request.form['race'])
    hours_per_week = float(request.form['hours_per_week'])
    arr= np.array([[age, workclass, education, marital_status, occupation, relationship, sex, race, hours_per_week]])
    pred = model.predict(arr)
    if (pred==0):
        result='Less than or equal to 50K'
    else:
        result='Greater than 50K'
    return render_template('index.html', prediction_text='The Predicted Salary  of the Employee is  {}'.format(result))
if __name__ == "__main__":
     app.run(debug=True)
